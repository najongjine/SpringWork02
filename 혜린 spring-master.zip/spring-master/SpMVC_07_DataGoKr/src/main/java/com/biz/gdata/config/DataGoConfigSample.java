package com.biz.gdata.config;

public class DataGoConfigSample {

	// 공공데이터포털에서 발급받은 인증키를 넣어서 
	// DataGoConfig로 클래스명을 변경 후 사용하세요
	public static final String goDataAuth = "YOUR KEY";
	
	
}
