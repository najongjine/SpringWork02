package com.biz.gdata.domain;

public class TourDTO {

}
