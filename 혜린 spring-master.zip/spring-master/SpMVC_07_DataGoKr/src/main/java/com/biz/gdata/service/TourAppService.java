package com.biz.gdata.service;

import org.springframework.stereotype.Service;

@Service
public class TourAppService {

	public String getAreaBaseListData(String t_city) {
		
		return null;
	}
	
}
