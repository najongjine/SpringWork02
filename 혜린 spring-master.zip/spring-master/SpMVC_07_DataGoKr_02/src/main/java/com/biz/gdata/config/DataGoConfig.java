package com.biz.gdata.config;

public class DataGoConfig {

	public static final String goDataAuth = "y%2FCFMaVqsyZkIA3RDTlaYV8HEPXAaLkE9KoM2ZL0dj%2FQhs2bWqPNVFvQnjjzbEW0vDqmAEWjtB3gooMlEZ%2BHkA%3D%3D";
	public static final String MY_APP_NAME = " 나의 관광 정보";
	
}
