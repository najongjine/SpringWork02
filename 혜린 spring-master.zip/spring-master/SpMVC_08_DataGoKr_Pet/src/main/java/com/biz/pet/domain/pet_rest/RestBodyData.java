package com.biz.pet.domain.pet_rest;

import java.util.List;

import com.biz.pet.domain.GoPetVO;

public class RestBodyData {

	public List<GoPetVO> list;
}
