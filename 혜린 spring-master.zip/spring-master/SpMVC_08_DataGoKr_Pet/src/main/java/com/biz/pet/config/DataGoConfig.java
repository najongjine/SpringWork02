package com.biz.pet.config;

public class DataGoConfig {

	// 공공DB
	public static final String DATA_GO_AUTH = "y%2FCFMaVqsyZkIA3RDTlaYV8HEPXAaLkE9KoM2ZL0dj%2FQhs2bWqPNVFvQnjjzbEW0vDqmAEWjtB3gooMlEZ%2BHkA%3D%3D";
	
	// 경기 동물 병원 정보
	public static final String DATA_KY_AUTH = "fc4ad57d332e47c6935c9a220c98474f";
	public static final String MY_APP = "My pet Life 1.0 (c) hyerin.you";
	
}
