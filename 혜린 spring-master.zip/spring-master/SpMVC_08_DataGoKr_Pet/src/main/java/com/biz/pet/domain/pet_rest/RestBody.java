package com.biz.pet.domain.pet_rest;

public class RestBody {

	public RestBodyData data;
	
}
